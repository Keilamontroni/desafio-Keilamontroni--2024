public class Exercicio1 {
}
